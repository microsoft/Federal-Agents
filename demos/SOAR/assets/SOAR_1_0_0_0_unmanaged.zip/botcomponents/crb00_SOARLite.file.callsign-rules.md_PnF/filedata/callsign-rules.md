# USAF Mission Callsign Naming Rules

This document defines the standard callsign naming conventions for USAF training missions. Callsigns are assigned based on mission type to provide immediate tactical context.

## Air Superiority Callsigns

Use these callsigns for air-to-air combat, defensive counter-air (DCA), and offensive counter-air (OCA) missions:

| Callsign | Typical Use |
|----------|-------------|
| RAPTOR | Primary fighter sweep |
| VIPER | Aggressive intercept |
| PHANTOM | Multi-role engagement |
| TALON | Quick reaction alert |
| EAGLE | Combat air patrol |
| SPECTRE | Night operations |

## Close Air Support (CAS) Callsigns

Use these callsigns for close air support, combat search and rescue (CSAR), and forward air controller missions:

| Callsign | Typical Use |
|----------|-------------|
| HAWG | A-10 CAS missions |
| THUNDER | Strike package lead |
| HAMMER | Precision strike |
| ANVIL | Heavy ordnance delivery |
| BULLDOG | Persistent overwatch |
| SENTINEL | FAC(A) missions |

## Full-Spectrum / Multi-Role Callsigns

Use these callsigns for exercises involving multiple mission types or complex scenarios:

| Callsign | Typical Use |
|----------|-------------|
| FORGE | Large force employment |
| TEMPEST | Dynamic retasking |
| VANGUARD | Package lead |
| OVERWATCH | ISR integration |
| IRONCLAD | Defensive operations |
| CATALYST | Joint operations |

## Callsign Assignment Rules

1. **Flight Lead Priority**: Flight leads choose the mission callsign based on primary mission type
2. **Consistency**: Once assigned, a callsign remains constant for the entire mission
3. **Numeric Suffix**: Add flight number and position (e.g., VIPER 1-1, VIPER 1-2)
4. **Deconfliction**: No two active missions should use the same callsign in the same AOR

## Flight Position Naming Convention

Format: `[CALLSIGN] [FLIGHT]-[POSITION]`

- **Flight 1**: Primary element (positions 1-1, 1-2)
- **Flight 2**: Secondary element (positions 2-1, 2-2)
- **-1 suffix**: Lead (Flight Lead or Element Lead)
- **-2 suffix**: Wingman

### Example:
- VIPER 1-1 = Flight Lead
- VIPER 1-2 = Wingman to Flight Lead
- VIPER 2-1 = Element Lead
- VIPER 2-2 = Wingman to Element Lead

## Adversary Callsigns (65th AGRS)

For aggressor/adversary training missions, use "RED" prefix:
- RED BANDIT
- RED BARON
- RED STAR

---

*Reference: AFI 11-202 Flying Operations, NTTR Range Procedures*
