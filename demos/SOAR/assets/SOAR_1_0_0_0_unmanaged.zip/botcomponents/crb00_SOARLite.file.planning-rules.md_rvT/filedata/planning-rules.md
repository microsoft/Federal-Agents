# Sortie Planning Rules and Procedures

This document defines the operational rules for planning sorties in USAF training exercises.

## Sortie Status Workflow

All sorties progress through these states:

```
Draft → Planned → Briefed → Airborne → Complete
         ↓
      Cancelled
```

| Status | Description |
|--------|-------------|
| **Draft** | Initial creation, not yet validated |
| **Planned** | Approved with crew and aircraft assigned |
| **Briefed** | Mission brief complete, ready for execution |
| **Airborne** | Currently executing |
| **Complete** | Mission concluded, debriefs pending |
| **Cancelled** | Mission cancelled (weather, maintenance, etc.) |

## Crew Rest Requirements

Per AFI 11-202V3, minimum crew rest periods must be observed:

| Flight Duration | Minimum Crew Rest | Maximum Duty Day |
|-----------------|-------------------|------------------|
| ≤ 4 hours | 12 hours | 12 hours |
| 4-8 hours | 12 hours | 14 hours |
| > 8 hours | 15 hours | 16 hours |

### Rules:
1. No pilot may fly more than **2 sorties per day**
2. Minimum **8 hours** between landing and next takeoff
3. Maximum **3 consecutive flying days** before mandatory rest day
4. Night sorties require **12 hours** crew rest regardless of duration

## Aircraft-Mission Compatibility

Aircraft assignment must match mission requirements:

| Aircraft Type | Air Superiority | CAS | Full-Spectrum |
|---------------|-----------------|-----|---------------|
| F-16C/D | ✅ Primary | ✅ Secondary | ✅ Yes |
| F-35A | ✅ Primary | ✅ Primary | ✅ Yes |
| A-10C | ❌ No | ✅ Primary | ⚠️ Limited |

### Aircraft Status Requirements:
- **Available**: Can be assigned to any compatible mission
- **Maintenance**: Cannot be scheduled until returned to Available
- **DNIF** (Duty Not Including Flying): Aircraft grounded for inspection

## Pilot Qualification Requirements

Pilots must hold current qualifications for assigned missions:

| Qualification | Required For |
|---------------|--------------|
| CMR (Combat Mission Ready) | All combat training sorties |
| Flight Lead | Position 1-1 in any flight |
| Instructor | Student training sorties |
| FAC(A) | Forward air controller missions |
| Adversary | Red Air/Aggressor missions |
| Night Current | Sorties with night landing |

### Qualification Rules:
1. Flight Leads must be **CMR qualified** and **Flight Lead certified**
2. Wingmen require minimum **Basic qualification** in aircraft type
3. Adversary missions require **Adversary qualification**
4. CAS missions require **CAS qualified** pilot or supervised training

## Sortie Validation Checklist

Before moving a sortie from Draft to Planned, verify:

- [ ] Aircraft is **Available** status
- [ ] All crew positions filled with **qualified** pilots
- [ ] Crew rest requirements met for all assigned pilots
- [ ] No conflicts with other assigned sorties
- [ ] Weather minimums expected to be met
- [ ] Training areas/ranges available
- [ ] Required support assets scheduled (tankers, aggressors)

## Scheduling Priorities

When conflicts arise, resolve using this priority order:

1. **Safety of Flight** - Always highest priority
2. **Exercise Primary Objectives** - Scheduled RED FLAG events
3. **Upgrade/Qualification Training** - Time-critical training
4. **Proficiency Training** - Standard currency maintenance
5. **Continuation Training** - Routine skill building

## Weather Minimums

Minimum weather conditions for training sorties:

| Mission Type | Ceiling | Visibility |
|--------------|---------|------------|
| Day VFR | 3,000 ft | 5 SM |
| Night VFR | 5,000 ft | 5 SM |
| Day IFR | 500 ft | 1 SM |
| Night IFR | 1,000 ft | 3 SM |
| Low Level | 2,000 ft | 5 SM |

---

*Reference: AFI 11-202V3 General Flight Rules, NTTR Range Procedures, Unit Local Flying Procedures*
